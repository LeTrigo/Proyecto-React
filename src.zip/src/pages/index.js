import Cart from "./components/Cart";
import CartItem from "./components/CartItem";
import ItemInCart from "./components/ItemInCart";

export default function Home() {
  return (
    <>
      <Cart />
    </>
  );
}
