import Button from 'react-bootstrap/Button';



function BuyButton() {
  return (
    <>
      <Button className='buy-button'>Comprar</Button>{' '}
    </>
  );
}

export default BuyButton