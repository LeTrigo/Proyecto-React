export const initialState = {
  products: [],
  cart: [],
};
