import eloquent from '../../../../public/img/eloquent-js.jpeg';



const CardImage = () => {
  return (
    <>
        <img src={ eloquent } alt="imagen del producto" />
    </>
  )
}

export default CardImage